using Unity.Entities;

namespace TinyRacing
{
    [GenerateAuthoringComponent]
    public struct ButtonAccelerateTag : IComponentData
    {
    }
}
