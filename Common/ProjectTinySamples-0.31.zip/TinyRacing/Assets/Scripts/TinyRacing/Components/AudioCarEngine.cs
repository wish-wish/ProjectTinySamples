using Unity.Entities;

[GenerateAuthoringComponent]
public struct AudioCarEngine : IComponentData
{
}
