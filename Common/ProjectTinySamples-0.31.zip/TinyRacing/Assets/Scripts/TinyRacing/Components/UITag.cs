using Unity.Entities;

namespace TinyRacing
{
    [GenerateAuthoringComponent]
    public struct UITag : IComponentData
    {
    }
}
