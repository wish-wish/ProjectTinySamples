using Unity.Entities;

namespace TinyRacing
{
    [GenerateAuthoringComponent]
    public struct EndingScene : IComponentData
    {
    }
}
