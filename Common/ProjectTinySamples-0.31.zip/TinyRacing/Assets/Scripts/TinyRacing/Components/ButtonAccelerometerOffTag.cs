using Unity.Entities;

namespace TinyRacing
{
    [GenerateAuthoringComponent]
    public struct ButtonAccelerometerOffTag : IComponentData
    {
    }
}
