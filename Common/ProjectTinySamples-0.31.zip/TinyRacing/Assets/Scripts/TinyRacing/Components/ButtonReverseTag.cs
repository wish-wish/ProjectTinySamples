using Unity.Entities;

namespace TinyRacing
{
    [GenerateAuthoringComponent]
    public struct ButtonReverseTag : IComponentData
    {
    }
}
