using Unity.Entities;

[GenerateAuthoringComponent]
public struct AudioAICarEngine : IComponentData
{
}
