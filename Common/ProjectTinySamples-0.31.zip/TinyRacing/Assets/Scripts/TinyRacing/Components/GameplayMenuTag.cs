using Unity.Entities;

namespace TinyRacing
{
    [GenerateAuthoringComponent]
    public struct GameplayMenuTag : IComponentData
    {
    }
}
