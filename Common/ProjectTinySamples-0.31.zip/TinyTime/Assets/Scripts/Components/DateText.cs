﻿using Unity.Entities;

namespace TinyTime
{
    [GenerateAuthoringComponent]
    public struct DateText : IComponentData
    {
    }
}
