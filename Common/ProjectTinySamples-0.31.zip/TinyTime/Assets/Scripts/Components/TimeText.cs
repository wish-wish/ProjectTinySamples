﻿using Unity.Entities;

namespace TinyTime
{
    [GenerateAuthoringComponent]
    public struct TimeText : IComponentData
    {
    }
}
