using Unity.Entities;
using Unity.Mathematics;

namespace TinyKitchen
{
    [GenerateAuthoringComponent]
    public struct FanAnimBladesComponent : IComponentData
    {
    }
}
