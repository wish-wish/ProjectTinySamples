using System.Collections.Generic;
using Unity.Entities;

namespace TinyKitchen
{
    public struct FoodSpawnerComponent: IComponentData
    {
    }
}