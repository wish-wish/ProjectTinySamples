using Unity.Entities;

namespace TinyKitchen
{
    [GenerateAuthoringComponent]
    public struct UIFanSpeed : IComponentData
    {
        
    }
}