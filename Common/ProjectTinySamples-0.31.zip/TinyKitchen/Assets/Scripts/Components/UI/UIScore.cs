using Unity.Entities;

namespace TinyKitchen
{
    [GenerateAuthoringComponent]
    public struct UIScore : IComponentData
    {
        
    }
}