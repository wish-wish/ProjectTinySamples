﻿using Unity.Entities;

namespace TinyPhysics
{
    [GenerateAuthoringComponent]
    public struct MoveWithKeyboard : IComponentData
    {
    }
}
