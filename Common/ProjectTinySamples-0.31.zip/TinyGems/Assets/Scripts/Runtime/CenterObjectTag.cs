using Unity.Entities;

namespace Unity.TinyGems
{
    [GenerateAuthoringComponent]
    public struct CenterObjectTag : IComponentData
    {
    }
}